#include "sboxes.h"

#ifndef KWAN
#error "You must compile with -DKWAN.  Set this and then recompile cliconfig.cpp"
#endif

void
s1 (
	unsigned long	a1,
	unsigned long	a2,
	unsigned long	a3,
	unsigned long	a4,
	unsigned long	a5,
	unsigned long	a6,
	unsigned long	&out1,
	unsigned long	&out2,
	unsigned long	&out3,
	unsigned long	&out4
) {
	unsigned long	x1, x2, x3, x4, x5, x6, x7, x8;
	unsigned long	x9, x10, x11, x12, x13, x14, x15, x16;
	unsigned long	x17, x18, x19, x20, x21, x22, x23, x24;
	unsigned long	x25, x26, x27, x28, x29, x30, x31, x32;
	unsigned long	x33, x34, x35, x36, x37, x38, x39, x40;
	unsigned long	x41, x42, x43, x44, x45, x46, x47, x48;
	unsigned long	x49, x50, x51, x52, x53, x54, x55, x56;
	unsigned long	x57, x58, x59, x60, x61, x62, x63, x64;
	unsigned long	x65, x66, x67, x68, x69, x70, x71, x72;
	unsigned long	x73, x74, x75, x76, x77, x78, x79, x80;
	unsigned long	x81, x82, x83, x84, x85, x86, x87, x88;
	unsigned long	x89, x90, x91, x92, x93, x94, x95;

	x1 = ~a2;
	x2 = ~a6;
	x5 = x2 & x1;
	x6 = a5 ^ x5;
	x4 = a1 & x6;
	x7 = x1 ^ a6;
	x8 = a5 ^ x7;
	x9 = x4 ^ x8;
	x3 = a3 & x9;
	x11 = a5 & a2;
	x12 = x11 ^ x5;
	x10 = a1 & x12;
	x13 = a5 & a6;
	x14 = x10 ^ x13;
	x15 = x3 ^ x14;
	x16 = a4 & x15;
	x20 = x2 | x1;
	x19 = a5 & x20;
	x21 = x19 ^ a2;
	x18 = a1 & x21;
	x22 = x18 ^ x1;
	x17 = a3 & x22;
	x24 = ~x19;
	x23 = a1 & x24;
	x25 = x23 ^ x8;
	x26 = x17 ^ x25;
	x27 = x16 ^ x26;
	out1 ^= x27;
	x30 = x1 | a6;
	x31 = x13 ^ x30;
	x29 = a1 & x31;
	x32 = x13 ^ a6;
	x33 = x29 ^ x32;
	x28 = a3 & x33;
	x34 = a1 & x19;
	x35 = a5 & x1;
	x36 = a2 | a6;
	x37 = x35 ^ x36;
	x38 = x34 ^ x37;
	x39 = x28 ^ x38;
	x40 = a4 & x39;
	x43 = a5 & x36;
	x44 = x43 ^ x30;
	x42 = a1 & x44;
	x45 = a5 & x2;
	x46 = x45 ^ x20;
	x47 = x42 ^ x46;
	x41 = a3 & x47;
	x48 = a1 & x37;
	x49 = x13 ^ x5;
	x50 = x48 ^ x49;
	x51 = x41 ^ x50;
	x52 = x40 ^ x51;
	out2 ^= x52;
	x54 = x29 ^ x5;
	x53 = a3 & x54;
	x57 = x2 & a2;
	x56 = a5 & x57;
	x58 = x56 ^ x57;
	x55 = a1 & x58;
	x60 = x2 | a2;
	x59 = a5 & x60;
	x61 = x59 ^ x30;
	x62 = x55 ^ x61;
	x63 = x53 ^ x62;
	x64 = a4 & x63;
	x66 = x55 ^ x37;
	x65 = a3 & x66;
	x67 = a1 & x61;
	x68 = x35 ^ x60;
	x69 = x67 ^ x68;
	x70 = x65 ^ x69;
	x71 = x64 ^ x70;
	out3 ^= x71;
	x74 = x45 ^ x5;
	x73 = a1 & x74;
	x72 = a3 & x73;
	x76 = x35 ^ x2;
	x75 = a1 & x76;
	x77 = x11 ^ x20;
	x78 = x75 ^ x77;
	x79 = x72 ^ x78;
	x80 = a4 & x79;
	x83 = x19 ^ x1;
	x82 = a1 & x83;
	x84 = a2 & a6;
	x85 = x19 ^ x84;
	x86 = x82 ^ x85;
	x81 = a3 & x86;
	x88 = a5 & x5;
	x89 = x88 ^ a6;
	x87 = a1 & x89;
	x91 = a2 ^ a6;
	x90 = a5 & x91;
	x92 = x90 ^ x57;
	x93 = x87 ^ x92;
	x94 = x81 ^ x93;
	x95 = x80 ^ x94;
	out4 ^= x95;
}


void
s2 (
	unsigned long	a1,
	unsigned long	a2,
	unsigned long	a3,
	unsigned long	a4,
	unsigned long	a5,
	unsigned long	a6,
	unsigned long	&out1,
	unsigned long	&out2,
	unsigned long	&out3,
	unsigned long	&out4
) {
	unsigned long	x1, x2, x3, x4, x5, x6, x7, x8;
	unsigned long	x9, x10, x11, x12, x13, x14, x15, x16;
	unsigned long	x17, x18, x19, x20, x21, x22, x23, x24;
	unsigned long	x25, x26, x27, x28, x29, x30, x31, x32;
	unsigned long	x33, x34, x35, x36, x37, x38, x39, x40;
	unsigned long	x41, x42, x43, x44, x45, x46, x47, x48;
	unsigned long	x49, x50, x51, x52, x53, x54, x55, x56;
	unsigned long	x57, x58, x59, x60, x61, x62, x63, x64;
	unsigned long	x65, x66, x67, x68, x69, x70, x71, x72;
	unsigned long	x73, x74, x75, x76, x77, x78, x79, x80;
	unsigned long	x81, x82, x83, x84;

	x1 = ~a5;
	x2 = ~a6;
	x5 = x2 & a5;
	x4 = a2 & x5;
	x6 = x4 ^ x5;
	x3 = a1 & x6;
	x7 = a2 & x1;
	x8 = x7 ^ a5;
	x9 = x3 ^ x8;
	x10 = a4 & x9;
	x13 = a2 & x2;
	x14 = a5 & a6;
	x15 = x13 ^ x14;
	x12 = a1 & x15;
	x16 = ~x13;
	x17 = x12 ^ x16;
	x11 = a3 & x17;
	x20 = x1 & a6;
	x19 = a2 & x20;
	x21 = x2 | x1;
	x22 = x19 ^ x21;
	x18 = a1 & x22;
	x23 = a2 & a6;
	x24 = x1 ^ a6;
	x25 = x23 ^ x24;
	x26 = x18 ^ x25;
	x27 = x11 ^ x26;
	x28 = x10 ^ x27;
	out1 ^= x28;
	x29 = a3 & x14;
	x30 = a1 & x4;
	x31 = x13 ^ x21;
	x32 = x30 ^ x31;
	x33 = x29 ^ x32;
	x34 = a4 & x33;
	x36 = a2 ^ a6;
	x37 = x30 ^ x36;
	x35 = a3 & x37;
	x38 = a2 ^ x24;
	x39 = a1 ^ x38;
	x40 = x35 ^ x39;
	x41 = x34 ^ x40;
	out2 ^= x41;
	x43 = a1 & x38;
	x44 = x43 ^ x24;
	x42 = a3 & x44;
	x47 = x2 | a5;
	x46 = a2 & x47;
	x48 = x46 ^ a5;
	x45 = a1 & x48;
	x49 = ~x19;
	x50 = x45 ^ x49;
	x51 = x42 ^ x50;
	x52 = a4 & x51;
	x56 = x1 | a6;
	x55 = a2 & x56;
	x57 = x55 ^ x1;
	x54 = a1 & x57;
	x58 = x23 ^ a5;
	x59 = x54 ^ x58;
	x53 = a3 & x59;
	x61 = a2 & x24;
	x62 = x61 ^ x21;
	x60 = a1 & x62;
	x63 = a2 & x21;
	x64 = x63 ^ x1;
	x65 = x60 ^ x64;
	x66 = x53 ^ x65;
	x67 = x52 ^ x66;
	out3 ^= x67;
	x69 = x23 ^ x14;
	x68 = a1 & x69;
	x70 = x4 ^ x21;
	x71 = x68 ^ x70;
	x72 = a4 & x71;
	x75 = x2 & x1;
	x76 = x19 ^ x75;
	x74 = a1 & x76;
	x77 = x4 ^ x24;
	x78 = x74 ^ x77;
	x73 = a3 & x78;
	x80 = x55 ^ x47;
	x79 = a1 & x80;
	x81 = ~x23;
	x82 = x79 ^ x81;
	x83 = x73 ^ x82;
	x84 = x72 ^ x83;
	out4 ^= x84;
}


void
s3 (
	unsigned long	a1,
	unsigned long	a2,
	unsigned long	a3,
	unsigned long	a4,
	unsigned long	a5,
	unsigned long	a6,
	unsigned long	&out1,
	unsigned long	&out2,
	unsigned long	&out3,
	unsigned long	&out4
) {
	unsigned long	x1, x2, x3, x4, x5, x6, x7, x8;
	unsigned long	x9, x10, x11, x12, x13, x14, x15, x16;
	unsigned long	x17, x18, x19, x20, x21, x22, x23, x24;
	unsigned long	x25, x26, x27, x28, x29, x30, x31, x32;
	unsigned long	x33, x34, x35, x36, x37, x38, x39, x40;
	unsigned long	x41, x42, x43, x44, x45, x46, x47, x48;
	unsigned long	x49, x50, x51, x52, x53, x54, x55, x56;
	unsigned long	x57, x58, x59, x60, x61, x62, x63, x64;
	unsigned long	x65, x66, x67, x68, x69, x70, x71, x72;
	unsigned long	x73, x74, x75, x76, x77, x78, x79, x80;
	unsigned long	x81, x82, x83, x84, x85, x86, x87, x88;
	unsigned long	x89;

	x1 = ~a1;
	x2 = ~a2;
	x5 = a6 & x1;
	x4 = a5 & x5;
	x6 = x2 & x1;
	x7 = x4 ^ x6;
	x3 = a3 & x7;
	x9 = a6 & x6;
	x10 = x9 ^ x6;
	x8 = a5 & x10;
	x11 = a1 | a2;
	x12 = x5 ^ x11;
	x13 = x8 ^ x12;
	x14 = x3 ^ x13;
	x15 = a4 & x14;
	x19 = a1 ^ a2;
	x18 = a6 & x19;
	x20 = x18 ^ x2;
	x17 = a5 & x20;
	x21 = x1 | a2;
	x22 = x17 ^ x21;
	x16 = a3 & x22;
	x23 = a6 & a1;
	x24 = x2 | a1;
	x25 = x23 ^ x24;
	x26 = a5 ^ x25;
	x27 = x16 ^ x26;
	x28 = x15 ^ x27;
	out1 ^= x28;
	x30 = a5 & x23;
	x31 = x1 & a2;
	x32 = x30 ^ x31;
	x29 = a3 & x32;
	x34 = ~x5;
	x33 = a5 & x34;
	x35 = a6 & x2;
	x36 = x35 ^ x31;
	x37 = x33 ^ x36;
	x38 = x29 ^ x37;
	x39 = a4 & x38;
	x42 = a6 & x31;
	x43 = x42 ^ x24;
	x41 = a5 & x43;
	x44 = x41 ^ x43;
	x40 = a3 & x44;
	x46 = x42 ^ x31;
	x45 = a5 & x46;
	x47 = a6 & x24;
	x48 = x2 & a1;
	x49 = x47 ^ x48;
	x50 = x45 ^ x49;
	x51 = x40 ^ x50;
	x52 = x39 ^ x51;
	out2 ^= x52;
	x54 = x9 ^ x24;
	x55 = x33 ^ x54;
	x53 = a3 & x55;
	x57 = a6 & x21;
	x58 = x57 ^ x19;
	x56 = a5 & x58;
	x59 = x57 ^ x6;
	x60 = x56 ^ x59;
	x61 = x53 ^ x60;
	x62 = a4 & x61;
	x65 = x5 ^ x1;
	x64 = a5 & x65;
	x66 = x35 ^ a2;
	x67 = x64 ^ x66;
	x63 = a3 & x67;
	x68 = x1 ^ a2;
	x69 = x57 ^ x68;
	x70 = x41 ^ x69;
	x71 = x63 ^ x70;
	x72 = x62 ^ x71;
	out3 ^= x72;
	x75 = a1 & a2;
	x74 = a6 & x75;
	x73 = a3 & x74;
	x76 = a5 & x1;
	x77 = ~x23;
	x78 = x76 ^ x77;
	x79 = x73 ^ x78;
	x80 = a4 & x79;
	x82 = a5 & x21;
	x83 = x74 ^ x48;
	x84 = x82 ^ x83;
	x81 = a3 & x84;
	x85 = a5 & x83;
	x86 = x57 ^ x11;
	x87 = x85 ^ x86;
	x88 = x81 ^ x87;
	x89 = x80 ^ x88;
	out4 ^= x89;
}


void
s4 (
	unsigned long	a1,
	unsigned long	a2,
	unsigned long	a3,
	unsigned long	a4,
	unsigned long	a5,
	unsigned long	a6,
	unsigned long	&out1,
	unsigned long	&out2,
	unsigned long	&out3,
	unsigned long	&out4
) {
	unsigned long	x1, x2, x3, x4, x5, x6, x7, x8;
	unsigned long	x9, x10, x11, x12, x13, x14, x15, x16;
	unsigned long	x17, x18, x19, x20, x21, x22, x23, x24;
	unsigned long	x25, x26, x27, x28, x29, x30, x31, x32;
	unsigned long	x33, x34, x35, x36, x37, x38, x39, x40;
	unsigned long	x41, x42, x43, x44, x45, x46, x47, x48;
	unsigned long	x49, x50, x51, x52, x53, x54, x55, x56;
	unsigned long	x57, x58, x59, x60, x61, x62, x63, x64;
	unsigned long	x65, x66, x67, x68, x69, x70, x71, x72;
	unsigned long	x73, x74, x75, x76, x77;

	x1 = ~a3;
	x2 = ~a5;
	x5 = a3 ^ a5;
	x4 = a2 & x5;
	x7 = x1 | a5;
	x6 = a1 & x7;
	x8 = x6 ^ x2;
	x9 = x4 ^ x8;
	x3 = a4 & x9;
	x12 = x1 & a5;
	x11 = a1 & x12;
	x13 = x2 | a3;
	x14 = x11 ^ x13;
	x10 = a2 & x14;
	x15 = x1 ^ a5;
	x16 = x11 ^ x15;
	x17 = x10 ^ x16;
	x18 = x3 ^ x17;
	x19 = a6 & x18;
	x22 = a1 & x15;
	x23 = x22 ^ a5;
	x21 = a2 & x23;
	x24 = ~x6;
	x25 = x21 ^ x24;
	x20 = a4 & x25;
	x27 = a3 | a5;
	x28 = x11 ^ x27;
	x26 = a2 & x28;
	x29 = a1 ^ x12;
	x30 = x26 ^ x29;
	x31 = x20 ^ x30;
	x32 = x19 ^ x31;
	out1 ^= x32;
	x33 = x11 ^ x5;
	x34 = x10 ^ x33;
	x35 = x3 ^ x34;
	x36 = a6 & x35;
	x39 = x22 ^ a3;
	x38 = a2 & x39;
	x40 = x38 ^ a5;
	x37 = a4 & x40;
	x41 = a2 & x1;
	x42 = a1 & x13;
	x43 = x42 ^ x7;
	x44 = x41 ^ x43;
	x45 = x37 ^ x44;
	x46 = x36 ^ x45;
	out2 ^= x46;
	x48 = x2 | x1;
	x49 = x42 ^ x48;
	x50 = x4 ^ x49;
	x47 = a4 & x50;
	x53 = x2 & a3;
	x52 = a1 & x53;
	x54 = x52 ^ x15;
	x51 = a2 & x54;
	x55 = x22 ^ x2;
	x56 = x51 ^ x55;
	x57 = x47 ^ x56;
	x58 = a6 & x57;
	x60 = x42 ^ x12;
	x61 = x38 ^ x60;
	x59 = a4 & x61;
	x63 = ~x42;
	x62 = a2 & x63;
	x64 = x62 ^ x16;
	x65 = x59 ^ x64;
	x66 = x58 ^ x65;
	out3 ^= x66;
	x67 = x51 ^ x23;
	x68 = x47 ^ x67;
	x69 = a6 & x68;
	x71 = x21 ^ x2;
	x70 = a4 & x71;
	x73 = x22 ^ x5;
	x72 = a2 & x73;
	x74 = x6 ^ x1;
	x75 = x72 ^ x74;
	x76 = x70 ^ x75;
	x77 = x69 ^ x76;
	out4 ^= x77;
}


void
s5 (
	unsigned long	a1,
	unsigned long	a2,
	unsigned long	a3,
	unsigned long	a4,
	unsigned long	a5,
	unsigned long	a6,
	unsigned long	&out1,
	unsigned long	&out2,
	unsigned long	&out3,
	unsigned long	&out4
) {
	unsigned long	x1, x2, x3, x4, x5, x6, x7, x8;
	unsigned long	x9, x10, x11, x12, x13, x14, x15, x16;
	unsigned long	x17, x18, x19, x20, x21, x22, x23, x24;
	unsigned long	x25, x26, x27, x28, x29, x30, x31, x32;
	unsigned long	x33, x34, x35, x36, x37, x38, x39, x40;
	unsigned long	x41, x42, x43, x44, x45, x46, x47, x48;
	unsigned long	x49, x50, x51, x52, x53, x54, x55, x56;
	unsigned long	x57, x58, x59, x60, x61, x62, x63, x64;
	unsigned long	x65, x66, x67, x68, x69, x70, x71, x72;
	unsigned long	x73, x74, x75, x76, x77, x78, x79, x80;
	unsigned long	x81, x82, x83, x84, x85, x86, x87, x88;
	unsigned long	x89, x90, x91, x92, x93, x94, x95, x96;

	x1 = ~a3;
	x2 = ~a6;
	x5 = a4 & x2;
	x6 = x5 ^ a6;
	x4 = a1 & x6;
	x7 = a3 & a6;
	x8 = a4 ^ x7;
	x9 = x4 ^ x8;
	x3 = a2 & x9;
	x11 = a4 & a3;
	x12 = x2 | a3;
	x13 = x11 ^ x12;
	x10 = a1 & x13;
	x15 = x1 | a6;
	x14 = a4 & x15;
	x16 = x14 ^ x2;
	x17 = x10 ^ x16;
	x18 = x3 ^ x17;
	x19 = a5 & x18;
	x23 = x1 ^ a6;
	x22 = a4 & x23;
	x24 = x22 ^ x7;
	x21 = a1 & x24;
	x25 = x2 | x1;
	x26 = x5 ^ x25;
	x27 = x21 ^ x26;
	x20 = a2 & x27;
	x29 = a4 & a6;
	x30 = x2 & a3;
	x31 = x29 ^ x30;
	x28 = a1 & x31;
	x33 = a3 | a6;
	x32 = a4 & x33;
	x34 = x1 & a6;
	x35 = x32 ^ x34;
	x36 = x28 ^ x35;
	x37 = x20 ^ x36;
	x38 = x19 ^ x37;
	out1 ^= x38;
	x40 = x22 ^ a6;
	x39 = a1 & x40;
	x41 = a4 & x7;
	x42 = x41 ^ x25;
	x43 = x39 ^ x42;
	x44 = a5 & x43;
	x47 = x32 ^ x33;
	x46 = a1 & x47;
	x48 = a4 & x25;
	x49 = x48 ^ x7;
	x50 = x46 ^ x49;
	x45 = a2 & x50;
	x51 = x48 ^ x33;
	x52 = a1 ^ x51;
	x53 = x45 ^ x52;
	x54 = x44 ^ x53;
	out2 ^= x54;
	x57 = x29 ^ x25;
	x56 = a1 & x57;
	x58 = x2 & x1;
	x59 = a4 ^ x58;
	x60 = x56 ^ x59;
	x55 = a2 & x60;
	x62 = a3 ^ a6;
	x63 = x14 ^ x62;
	x61 = a1 & x63;
	x64 = x14 ^ x23;
	x65 = x61 ^ x64;
	x66 = x55 ^ x65;
	x67 = a5 & x66;
	x69 = ~x32;
	x70 = x61 ^ x69;
	x68 = a2 & x70;
	x72 = x14 ^ x58;
	x71 = a1 & x72;
	x73 = a4 & x58;
	x74 = x73 ^ x25;
	x75 = x71 ^ x74;
	x76 = x68 ^ x75;
	x77 = x67 ^ x76;
	out3 ^= x77;
	x79 = a1 & x59;
	x80 = x29 ^ x23;
	x81 = x79 ^ x80;
	x78 = a2 & x81;
	x82 = a1 & x14;
	x83 = x14 ^ x33;
	x84 = x82 ^ x83;
	x85 = x78 ^ x84;
	x86 = a5 & x85;
	x89 = a4 & x1;
	x90 = x89 ^ x58;
	x88 = a1 & x90;
	x91 = x88 ^ x6;
	x87 = a2 & x91;
	x92 = a1 & x51;
	x93 = x41 ^ x30;
	x94 = x92 ^ x93;
	x95 = x87 ^ x94;
	x96 = x86 ^ x95;
	out4 ^= x96;
}


void
s6 (
	unsigned long	a1,
	unsigned long	a2,
	unsigned long	a3,
	unsigned long	a4,
	unsigned long	a5,
	unsigned long	a6,
	unsigned long	&out1,
	unsigned long	&out2,
	unsigned long	&out3,
	unsigned long	&out4
) {
	unsigned long	x1, x2, x3, x4, x5, x6, x7, x8;
	unsigned long	x9, x10, x11, x12, x13, x14, x15, x16;
	unsigned long	x17, x18, x19, x20, x21, x22, x23, x24;
	unsigned long	x25, x26, x27, x28, x29, x30, x31, x32;
	unsigned long	x33, x34, x35, x36, x37, x38, x39, x40;
	unsigned long	x41, x42, x43, x44, x45, x46, x47, x48;
	unsigned long	x49, x50, x51, x52, x53, x54, x55, x56;
	unsigned long	x57, x58, x59, x60, x61, x62, x63, x64;
	unsigned long	x65, x66, x67, x68, x69, x70, x71, x72;
	unsigned long	x73, x74, x75, x76, x77, x78, x79, x80;
	unsigned long	x81, x82, x83, x84, x85, x86, x87;

	x1 = ~a2;
	x2 = ~a3;
	x5 = a5 & x1;
	x6 = x1 | a3;
	x7 = x5 ^ x6;
	x4 = a4 & x7;
	x9 = x2 | a2;
	x8 = a5 & x9;
	x10 = x8 ^ x9;
	x11 = x4 ^ x10;
	x3 = a1 & x11;
	x13 = a5 & x2;
	x14 = x13 ^ x9;
	x12 = a4 & x14;
	x15 = x13 ^ a3;
	x16 = x12 ^ x15;
	x17 = x3 ^ x16;
	x18 = a6 & x17;
	x19 = a1 & x15;
	x20 = a4 & x15;
	x21 = a5 ^ x6;
	x22 = x20 ^ x21;
	x23 = x19 ^ x22;
	x24 = x18 ^ x23;
	out1 ^= x24;
	x27 = a2 & a3;
	x28 = a5 ^ x27;
	x26 = a4 & x28;
	x30 = x1 & a3;
	x29 = a5 & x30;
	x31 = x29 ^ x30;
	x32 = x26 ^ x31;
	x25 = a1 & x32;
	x34 = a5 & a2;
	x33 = a4 & x34;
	x35 = ~x33;
	x36 = x25 ^ x35;
	x37 = a6 & x36;
	x41 = x1 ^ a3;
	x40 = a5 & x41;
	x39 = a4 & x40;
	x42 = a5 & x27;
	x43 = x42 ^ x9;
	x44 = x39 ^ x43;
	x38 = a1 & x44;
	x46 = a5 & a3;
	x47 = x46 ^ x1;
	x45 = a4 & x47;
	x48 = x13 ^ x41;
	x49 = x45 ^ x48;
	x50 = x38 ^ x49;
	x51 = x37 ^ x50;
	out2 ^= x51;
	x53 = a4 & x5;
	x54 = x29 ^ x2;
	x55 = x53 ^ x54;
	x52 = a1 & x55;
	x56 = a4 & a5;
	x57 = ~x34;
	x58 = x56 ^ x57;
	x59 = x52 ^ x58;
	x60 = a6 & x59;
	x62 = a2 | a3;
	x63 = x13 ^ x62;
	x64 = x33 ^ x63;
	x61 = a1 & x64;
	x65 = a4 & x57;
	x66 = x29 ^ x27;
	x67 = x65 ^ x66;
	x68 = x61 ^ x67;
	x69 = x60 ^ x68;
	out3 ^= x69;
	x72 = a2 ^ a3;
	x73 = x40 ^ x72;
	x71 = a4 & x73;
	x74 = x71 ^ x6;
	x70 = a1 & x74;
	x76 = x40 ^ x30;
	x75 = a4 & x76;
	x77 = x70 ^ x75;
	x78 = a6 & x77;
	x80 = ~x46;
	x81 = x20 ^ x80;
	x79 = a1 & x81;
	x83 = x46 ^ x62;
	x82 = a4 & x83;
	x84 = a5 ^ x30;
	x85 = x82 ^ x84;
	x86 = x79 ^ x85;
	x87 = x78 ^ x86;
	out4 ^= x87;
}


void
s7 (
	unsigned long	a1,
	unsigned long	a2,
	unsigned long	a3,
	unsigned long	a4,
	unsigned long	a5,
	unsigned long	a6,
	unsigned long	&out1,
	unsigned long	&out2,
	unsigned long	&out3,
	unsigned long	&out4
) {
	unsigned long	x1, x2, x3, x4, x5, x6, x7, x8;
	unsigned long	x9, x10, x11, x12, x13, x14, x15, x16;
	unsigned long	x17, x18, x19, x20, x21, x22, x23, x24;
	unsigned long	x25, x26, x27, x28, x29, x30, x31, x32;
	unsigned long	x33, x34, x35, x36, x37, x38, x39, x40;
	unsigned long	x41, x42, x43, x44, x45, x46, x47, x48;
	unsigned long	x49, x50, x51, x52, x53, x54, x55, x56;
	unsigned long	x57, x58, x59, x60, x61, x62, x63, x64;
	unsigned long	x65, x66, x67, x68, x69, x70, x71, x72;
	unsigned long	x73, x74, x75, x76, x77, x78, x79, x80;
	unsigned long	x81, x82, x83, x84, x85, x86;

	x1 = ~a1;
	x2 = ~a6;
	x4 = a2 & a1;
	x6 = x2 & x1;
	x5 = a3 & x6;
	x7 = a1 & a6;
	x8 = x5 ^ x7;
	x9 = x4 ^ x8;
	x3 = a5 & x9;
	x11 = x5 ^ x1;
	x10 = a2 & x11;
	x12 = x10 ^ a1;
	x13 = x3 ^ x12;
	x14 = a4 & x13;
	x17 = a3 & a1;
	x16 = a2 & x17;
	x18 = x1 | a6;
	x19 = x17 ^ x18;
	x20 = x16 ^ x19;
	x15 = a5 & x20;
	x22 = x5 ^ a1;
	x21 = a2 & x22;
	x24 = x2 | x1;
	x23 = a3 & x24;
	x25 = x1 & a6;
	x26 = x23 ^ x25;
	x27 = x21 ^ x26;
	x28 = x15 ^ x27;
	x29 = x14 ^ x28;
	out1 ^= x29;
	x31 = a2 & x25;
	x33 = a1 ^ a6;
	x32 = a3 & x33;
	x34 = x31 ^ x32;
	x30 = a5 & x34;
	x36 = x17 ^ x24;
	x35 = a2 & x36;
	x37 = x35 ^ x1;
	x38 = x30 ^ x37;
	x39 = a4 & x38;
	x41 = x1 ^ a6;
	x42 = x23 ^ x41;
	x40 = a2 & x42;
	x43 = x40 ^ x19;
	x44 = a5 ^ x43;
	x45 = x39 ^ x44;
	out2 ^= x45;
	x47 = a2 & x41;
	x48 = a3 & x25;
	x49 = x48 ^ x2;
	x50 = x47 ^ x49;
	x46 = a5 & x50;
	x52 = x48 ^ a1;
	x51 = a2 & x52;
	x53 = ~x48;
	x54 = x51 ^ x53;
	x55 = x46 ^ x54;
	x56 = a4 & x55;
	x60 = x2 & a1;
	x59 = a3 & x60;
	x58 = a2 & x59;
	x61 = x59 ^ x6;
	x62 = x58 ^ x61;
	x57 = a5 & x62;
	x64 = ~x59;
	x63 = a2 & x64;
	x65 = a3 & x41;
	x66 = x65 ^ x7;
	x67 = x63 ^ x66;
	x68 = x57 ^ x67;
	x69 = x56 ^ x68;
	out3 ^= x69;
	x71 = a2 & a6;
	x72 = x23 ^ x24;
	x73 = x71 ^ x72;
	x70 = a5 & x73;
	x74 = x23 ^ x7;
	x75 = x31 ^ x74;
	x76 = x70 ^ x75;
	x77 = a4 & x76;
	x79 = a2 & x7;
	x80 = ~x79;
	x78 = a5 & x80;
	x82 = ~x23;
	x81 = a2 & x82;
	x83 = a3 ^ x33;
	x84 = x81 ^ x83;
	x85 = x78 ^ x84;
	x86 = x77 ^ x85;
	out4 ^= x86;
}


void
s8 (
	unsigned long	a1,
	unsigned long	a2,
	unsigned long	a3,
	unsigned long	a4,
	unsigned long	a5,
	unsigned long	a6,
	unsigned long	&out1,
	unsigned long	&out2,
	unsigned long	&out3,
	unsigned long	&out4
) {
	unsigned long	x1, x2, x3, x4, x5, x6, x7, x8;
	unsigned long	x9, x10, x11, x12, x13, x14, x15, x16;
	unsigned long	x17, x18, x19, x20, x21, x22, x23, x24;
	unsigned long	x25, x26, x27, x28, x29, x30, x31, x32;
	unsigned long	x33, x34, x35, x36, x37, x38, x39, x40;
	unsigned long	x41, x42, x43, x44, x45, x46, x47, x48;
	unsigned long	x49, x50, x51, x52, x53, x54, x55, x56;
	unsigned long	x57, x58, x59, x60, x61, x62, x63, x64;
	unsigned long	x65, x66, x67, x68, x69, x70, x71, x72;
	unsigned long	x73, x74, x75, x76, x77, x78, x79, x80;
	unsigned long	x81, x82, x83, x84, x85, x86, x87, x88;

	x1 = ~a3;
	x2 = ~a5;
	x6 = x1 ^ a5;
	x5 = a4 & x6;
	x7 = x2 & a3;
	x8 = x5 ^ x7;
	x4 = a2 & x8;
	x10 = a3 ^ a5;
	x9 = a4 & x10;
	x11 = x9 ^ x6;
	x12 = x4 ^ x11;
	x3 = a6 & x12;
	x14 = a4 & a3;
	x13 = a2 & x14;
	x15 = x2 | x1;
	x16 = x9 ^ x15;
	x17 = x13 ^ x16;
	x18 = x3 ^ x17;
	x19 = a1 & x18;
	x22 = a4 & x1;
	x23 = x22 ^ x2;
	x21 = a2 & x23;
	x24 = ~x5;
	x25 = x21 ^ x24;
	x20 = a6 & x25;
	x27 = x5 ^ a5;
	x26 = a2 & x27;
	x28 = x14 ^ x6;
	x29 = x26 ^ x28;
	x30 = x20 ^ x29;
	x31 = x19 ^ x30;
	out1 ^= x31;
	x33 = x1 & a5;
	x34 = x22 ^ x33;
	x35 = x13 ^ x34;
	x32 = a6 & x35;
	x37 = x5 ^ x10;
	x36 = a2 & x37;
	x38 = x22 ^ x7;
	x39 = x36 ^ x38;
	x40 = x32 ^ x39;
	x41 = a1 & x40;
	x43 = a4 & x2;
	x44 = x43 ^ x6;
	x42 = a2 & x44;
	x45 = x2 | a3;
	x46 = a4 ^ x45;
	x47 = x42 ^ x46;
	x48 = a6 ^ x47;
	x49 = x41 ^ x48;
	out2 ^= x49;
	x52 = a4 & a5;
	x53 = a3 & a5;
	x54 = x52 ^ x53;
	x51 = a2 & x54;
	x55 = x43 ^ a5;
	x56 = x51 ^ x55;
	x50 = a6 & x56;
	x57 = a2 & x33;
	x58 = x43 ^ x45;
	x59 = x57 ^ x58;
	x60 = x50 ^ x59;
	x61 = a1 & x60;
	x64 = x5 ^ x6;
	x63 = a2 & x64;
	x62 = a6 & x63;
	x65 = a3 | a5;
	x66 = x52 ^ x65;
	x67 = a2 ^ x66;
	x68 = x62 ^ x67;
	x69 = x61 ^ x68;
	out3 ^= x69;
	x71 = a2 & x34;
	x72 = x71 ^ x16;
	x70 = a6 & x72;
	x74 = x43 ^ x7;
	x73 = a2 & x74;
	x75 = x73 ^ x65;
	x76 = x70 ^ x75;
	x77 = a1 & x76;
	x79 = a2 & x10;
	x81 = x1 | a5;
	x80 = a4 & x81;
	x82 = x80 ^ x33;
	x83 = x79 ^ x82;
	x78 = a6 & x83;
	x85 = ~x52;
	x84 = a2 & x85;
	x86 = x84 ^ x44;
	x87 = x78 ^ x86;
	x88 = x77 ^ x87;
	out4 ^= x88;
}
