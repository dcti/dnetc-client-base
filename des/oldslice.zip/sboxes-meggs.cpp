#include "sboxes.h"

void
s1 (
 unsigned long	hi32,
 unsigned long	hi16,
 unsigned long	t1,
 unsigned long	t2,
 unsigned long	t3,
 unsigned long	t4,
 unsigned long	&out1,
 unsigned long	&out2,
 unsigned long	&out3,
 unsigned long	&out4
) {
 unsigned long t5, t6, t7, t8, t9, t10, t11, t12, t13, t14;
 unsigned long t15, t16, t17, t18, t19, t20, t21, t22, t23;
 unsigned long t24, t25, t26, t27, t28, t29, t30, t31, t32;
 unsigned long t33, t34, t35, t36, t37, t38, t39, t40, t41;
 unsigned long t42, t43;

 unsigned long m1, m2, m3, m4;
 unsigned long o1, o2, o3, o4;

 unsigned long o11, o12, o13, o14;
 unsigned long o21, o22, o23, o24;
 unsigned long o31, o32, o33, o34;
 unsigned long o41, o42, o43, o44;

 m1 = hi32 & hi16;
 m2 = hi32 & ~hi16;
 m3 = ~hi32 & hi16;
 m4 = ~(hi32 | hi16);

 o4 = out4;

 t5   =   t4   ^  t1;    // 0x55aa55aa
 t8   =   t4   ^  t3;    // 0x66666666
 t6   =   t5   &  t3;    // 0x44884488
 t9   =   t8   &  t2;    // 0x60606060
 t7   =   t6   ^  t2;    // 0xb478b478 <----- 4-4
 o3 = out3;
 t10  =   t9   ^ ~t1;    // 0x609f609f <----- 3-3
 o44 = t7 & m4;
 t11  =   t4   |  t1;    // 0xffaaffaa
 o33 = t10 & m3;
 t12  =   t11  &  t7;    // 0xb428b428
 o4 ^= o44;
 t13  =   t12  ^ ~t3;    // 0x871b871b <----- 2-2
 o3 ^= o33;
 o2 = out2;
 t14  =   t4   |  t3;    // 0xeeeeeeee
 o22 = t13 & m2;
 t15  =   t14  &  t10;   // 0x608e608e
 o2 ^= o22;
 t16  =   t15  ^ ~t2;    // 0x6f816f81 <----- 4-3
 t17  =   t4   |  t2;    // 0xfafafafa
 o43 = t16 & m3;
 t18  =   t17  |  t6;    // 0xfefafefa
 o4 ^= o43;
 t19  =   t18  ^  t16;   // 0x917b917b <----- 4-1
 t20  =   t7   |  t1;    // 0xff78ff78
 o41 = t19 & m1;
 t21  =   t18  &  t13;   // 0x861a861a
 o1 = out1;
 o4 ^= o41;
 t22  =   t21  ^ ~t20;   // 0x869d869d <----- 1-1
 t23  =   t21  |  t7;    // 0xb67ab67a
 o11 = t22 & m1;
 t24  =   t23  ^  t1;    // 0x497a497a <----- 1-2
 o1 ^= o11;
 t25  =   t24  &  t20;   // 0x49784978 <----- 2-3
 o12 = t24 & m2;
 t26  =   t22  &  t13;   // 0x86198619
 o1 ^= o12;
 o23 = t25 & m3;
 t27  =   t26  ^ ~t1;    // 0x86e686e6 <----- 1-3
 o2 ^= o23;
 o13 = t27 & m3;
 t28  =   t10  |  t2;    // 0xf0fff0ff
 o1 ^= o13;
 t29  =   t28  ^  t27;   // 0x76197619 <----- 1-4
 t32  =   t25  &  t14;   // 0x48684868
 o14 = t29 & m4;
 t30  =   t29  |  t6;    // 0x76997699
 o1 ^= o14;
 t31  =   t30  ^ ~t9;    // 0xe906e906 <----- 4-2
 t33  =   t32  ^  t16;   // 0x27e927e9 <----- 3-1
 out1 = o1;
 t34  =   t19  &  t11;   // 0x912a912a
 o42 = t31 & m2;
 t35  =   t34  ^ ~t32;   // 0x26bd26bd <----- 2-4
 o31 = t33 & m1;
 o4 ^= o42;
 o3 ^= o31;
 o24 = t35 & m4;
 t36  =   t8   |  t7;    // 0xf67ef67e
 t37  =   t33  ^  t17;   // 0xdd13dd13
 o2 ^= o24;
 t38  =   t37  ^ ~t36;   // 0xd492d492 <----- 3-2
 t39  =   t31  | ~t11;   // 0xe957e957
 out4 = o4;
 o32 = t38 & m2;
 t40  =   t39  ^  t36;   // 0x1f291f29 <----- 3-4
 o3 ^= o32;
 t41  =   t9   |  t3;    // 0xecececec
 t42  =   t36  ^  t5;    // 0xa3d4a3d4
 o34 = t40 & m4;
 t43  =   t42  ^ ~t41;   // 0xb0c7b0c7 <----- 2-1
 o21 = t43 & m1;
 o3 ^= o34;
 out3 = o3;
 o2 ^= o21;
 out2 = o2;

}


void
s2 (
 unsigned long	hi32,
 unsigned long	hi16,
 unsigned long	t1,
 unsigned long	t2,
 unsigned long	t3,
 unsigned long	t4,
 unsigned long	&out1,
 unsigned long	&out2,
 unsigned long	&out3,
 unsigned long	&out4
) {
 unsigned long t5, t6, t7, t8, t9, t10, t11, t12, t13, t14;
 unsigned long t15, t16, t17, t18, t19, t20, t21, t22, t23;
 unsigned long t24, t25, t26, t27, t28, t29, t30, t31, t32;
 unsigned long /*t33, t34,*/ t35, t36, t37, t38, t39, t40, t41;

 unsigned long m1, m2, m3, m4;
 unsigned long o1, o2, o3, o4;

 unsigned long o11, o12, o13, o14;
 unsigned long o21, o22, o23;
 unsigned long o31, o32, o33, o34;
 unsigned long o41, o42, o43, o44;

 m3 = ~hi32 & hi16;
 m4 = ~(hi32 | hi16);

 o4 = out4;

 t5   =   t3   & ~t1;    // 0x00cc00cc
 m2 = hi32 & ~hi16;
 t6   =   t5   | ~t4;    // 0x55dd55dd
 t9   =   t4   ^  t1;    // 0x55aa55aa
 t7   =   t6   ^ ~t2;    // 0x5ad25ad2 <----- 4-2
 m1 = hi32 & hi16;
 o42 = t7 & m2;
 o3 = out3;
 t8   =   t7   |  t3;    // 0xdededede
 o4 ^= o42;
 t10  =   t9   ^  t8;    // 0x8b748b74 <----- 3-2
 t11  =   t4   |  t3;    // 0xeeeeeeee
 o1 = out1;
 t12  =   t9   ^  t7;    // 0x0f780f78
 o32 = t10 & m2;
 t13  =   t12  ^  t11;   // 0xe196e196 <----- 1-1
 o3 ^= o32;
 o11 = t13 & m1;
 t14  =   t6   |  t1;    // 0xffddffdd
 t15  =   t10  ^  t3;    // 0x47b847b8
 o1 ^= o11;
 t16  =   t15  ^  t14;   // 0xb865b865 <----- 4-3
 t17  =   t7   ^  t3;    // 0x961e961e
 o43 = t16 & m3;
 t18  =   t17  ^  t14;   // 0x69c369c3 <----- 1-3
 o4 ^= o43;
 o13 = t18 & m3;
 t19  =   t17  |  t1;    // 0xff1eff1e
 o1 ^= o13;
 o2 = out2;
 t20  =   t19  ^  t10;   // 0x746a746a <----- 3-1
 t21  =   t12  &  t6;    // 0x05580558
 o31 = t20 & m1;
 t22  =   t21  ^  t17;   // 0x93469346 <----- 2-3
 o3 ^= o31;
 o23 = t22 & m3;
 t23  =   t21  |  t3;    // 0xcddccddc
 o2 ^= o23;
 t24  =   t23  ^ ~t1;    // 0xcd23cd23 <----- 4-1
 t25  =   t11  ^  t2;    // 0x1e1e1e1e
 o41 = t24 & m1;
 t26  =   t25  ^ ~t15;   // 0xa659a659 <----- 1-4
 o4 ^= o41;
 o14 = t26 & m4;
 t27  =   t22  |  t20;   // 0xf76ef76e
 o1 ^= o14;
 t28  =   t27  ^ ~t25;   // 0x168f168f <----- 4-4
 t29  =   t11  &  t1;    // 0xee00ee00
 o44 = t28 & m4;
 t30  =   t29  ^  t27;   // 0x196e196e <----- 1-2
 o4 ^= o44;
 o12 = t30 & m2;
 t31  =   t18  ^  t4;    // 0xc369c369
 out4 = o4;
 o1 ^= o12;
 t32  =   t19  & ~t31;   // 0x3c163c16 <----- 2-2
 o22 = t32 & ~hi16;
 t35  =   t4   |  t2;    // 0xfafafafa
 o22 = o22 ^ m4;
 out1 = o1;
 t36  =   t35  & ~t22;   // 0x68b868b8
 o2 ^= o22;
 t37  =   t36  | ~t19;   // 0x68f968f9 <----- 2-1
 o21 = t37 & m1;
 t38  =   t37  &  t2;    // 0x60f060f0
 o2 ^= o21;
 t39  =   t38  ^ ~t5;    // 0x9fc39fc3 <----- 3-4
 t40  =   t15  &  t4;    // 0x02a802a8
 o34 = t39 & m4;
 t41  =   t40  ^ ~t39;   // 0x62946294 <----- 3-3
 o33 = t41 & m3;
 o3 ^= o34;
 out2 = o2;
 o3 ^= o33;

 out3 = o3;
}


void
s3 (
 unsigned long	a1,
 unsigned long	a2,
 unsigned long	a3,
 unsigned long	a4,
 unsigned long	a5,
 unsigned long	a6,
 unsigned long	&out1,
 unsigned long	&out2,
 unsigned long	&out3,
 unsigned long	&out4
) {
 unsigned long
     x1,x2,x5,x6,x9,x11,x19,x21,x23,x24,x31,x33,x35,x42,x43,x41,x48,x57,x74,x83;

 x1 = ~a1;
 x2 = ~a2;
 x5 = a6 & x1;
 x6 = x2 & x1;
 x9 = a6 & x6;
 x11 = a1 | a2;
 x19 = a1 ^ a2;
 x21 = x1 | a2;
 x23 = a6 & a1;
 x24 = x2 | a1;
 out1 ^=
     (a4 & ((a3 & ((a5 & x5) ^ x6)) ^ (a5 & (x9 ^ x6)) ^ x5 ^ x11)) ^
     (a3 & ((a5 & ((a6 & x19) ^ x2)) ^ x21)) ^ a5 ^ x23 ^ x24;

 x31 = x1 & a2;
 x33 = a5 & (~x5);
 x35 = a6 & x2;
 x42 = a6 & x31;
 x43 = x42 ^ x24;
 x41 = a5 & x43;
 x48 = x2 & a1;
 out2 ^=
     (a4 & ((a3 & ((a5 & x23) ^ x31)) ^ (x33 ^ x35 ^ x31))) ^
     (a3 & (x41 ^ x43)) ^ (a5 & (x42 ^ x31)) ^ (a6 & x24) ^ x48;

 x57 = a6 & x21;
 out3 ^=
     (a4 & ((a3 & (x33 ^ x9 ^ x24)) ^ (a5 & (x57 ^ x19)) ^ x57 ^ x6)) ^
     (a3 & ((a5 & (x5 ^ x1)) ^ x35 ^ a2)) ^ x41 ^ x57 ^ x1 ^ a2;

 x74 = a6 & a1 & a2;
 x83 = x74 ^ x48;
 out4 ^=
     (a4 & ((a3 & x74) ^ (a5 & x1) ^ (~x23))) ^
     (a3 & ((a5 & x21) ^ x83)) ^ (a5 & x83) ^ x57 ^ x11;
}


void
s4 (
 unsigned long	a1,
 unsigned long	a2,
 unsigned long	a3,
 unsigned long	a4,
 unsigned long	a5,
 unsigned long	a6,
 unsigned long	&out1,
 unsigned long	&out2,
 unsigned long	&out3,
 unsigned long	&out4
) {
 unsigned long
     x1,x2,x5,x4,x7,x6,x3,x12,x11,x13,x10,x15,x16,x22,x23,x21,x20,x38,x42,x47,x48,x51;

 x1 = ~a3;
 x2 = ~a5;
 x5 = a3 ^ a5;
 x4 = a2 & x5;
 x7 = x1 | a5;
 x6 = a1 & x7;
 x3 = a4 & (x4 ^ x6 ^ x2);
 x12 = x1 & a5;
 x11 = a1 & x12;
 x13 = x2 | a3;
 x10 = a2 & (x11 ^ x13);
 x15 = x1 ^ a5;
 x16 = x11 ^ x15;
 x22 = a1 & x15;
 x23 = x22 ^ a5;
 x21 = a2 & x23;
 x20 = x3 ^ x10;
 out1 ^=
     (a6 & (x20 ^ x16)) ^ (a4 & (x21 ^ (~x6))) ^ (a2 & (x11 ^ (a3 | a5))) ^ a1 ^ x12;

 x38 = a2 & (x22 ^ a3);
 x42 = a1 & x13;
 out2 ^=
     (a6 & (x3 ^ x10 ^ x11 ^ x5)) ^ (a4 & (x38 ^ a5)) ^ (a2 & x1) ^ x42 ^ x7;

 x47 = a4 & (x4 ^ x42 ^ (x2 | x1));
 x51 = a2 & ((a1 & x2 & a3) ^ x15);
 x48 = x47 ^ x51;
 out3 ^=
     (a6 & (x48 ^ x22 ^ x2)) ^ (a4 & (x38 ^ x42 ^ x12)) ^ (a2 & (~x42)) ^ x16;

 out4 ^=
     (a6 & (x48 ^ x23)) ^ (a4 & (x21 ^ x2)) ^ (a2 & (x22 ^ x5)) ^ x6 ^ x1;
}


void
s5 (
 unsigned long	a1,
 unsigned long	a2,
 unsigned long	a3,
 unsigned long	a4,
 unsigned long	a5,
 unsigned long	a6,
 unsigned long	&out1,
 unsigned long	&out2,
 unsigned long	&out3,
 unsigned long	&out4
) {
 unsigned long	x1,x2,x5,x6,x7,x14,x23,x22,x25,x29,x30,x33,x32,x41,x48,x51,x58,x59,x61;

 x1 = ~a3;
 x2 = ~a6;
 x5 = a4 & x2;
 x6 = x5 ^ a6;
 x7 = a3 & a6;
 x14 = a4 & (x1 | a6);
 x23 = x1 ^ a6;
 x22 = a4 & x23;
 x25 = x2 | x1;
 x29 = a4 & a6;
 x30 = x2 & a3;
 x33 = a3 | a6;
 x32 = a4 & x33;
 out1 ^=
     (a5 & ((a2 & ((a1 & x6) ^ a4 ^ x7)) ^ (a1 & ((a4 & a3) ^ (x2 | a3))) ^ x14 ^ x2)) ^
     (a2 & ((a1 & (x22 ^ x7)) ^ x5 ^ x25)) ^ (a1 & (x29 ^ x30)) ^ x32 ^ (x1 & a6);

 x41 = a4 & x7;
 x48 = a4 & x25;
 x51 = x48 ^ x33;
 out2 ^=
     (a5 & ((a1 & (x22 ^ a6)) ^ x41 ^ x25)) ^
     (a2 & ((a1 & (x32 ^ x33)) ^ x48 ^ x7)) ^ a1 ^ x51;

 x58 = x2 & x1;
 x59 = a4 ^ x58;
 x61 = a1 & (x14 ^ a3 ^ a6);
 out3 ^=
     (a5 & ((a2 & ((a1 & (x29 ^ x25)) ^ x59)) ^ x61 ^ x14 ^ x23)) ^
     (a2 & (x61 ^ (~x32))) ^ (a1 & (x14 ^ x58)) ^ (a4 & x58) ^ x25;

 out4 ^=
     (a5 & ((a2 & ((a1 & x59) ^ x29 ^ x23)) ^ (a1 & x14) ^ x14 ^ x33)) ^
     (a2 & ((a1 & ((a4 & x1) ^ x58)) ^ x6)) ^ (a1 & x51) ^ x41 ^ x30;
}


void
s6 (
 unsigned long	a1,
 unsigned long	a2,
 unsigned long	a3,
 unsigned long	a4,
 unsigned long	a5,
 unsigned long	a6,
 unsigned long	&out1,
 unsigned long	&out2,
 unsigned long	&out3,
 unsigned long	&out4
) {
 unsigned long	x1,x2,x5,x6,x9,x13,x15,x20,x27,x29,x30,x34,x33,x41,x40,x46,x57,x62;

 x1 = ~a2;
 x2 = ~a3;
 x5 = a5 & x1;
 x6 = x1 | a3;
 x9 = x2 | a2;
 x13 = a5 & x2;
 x15 = x13 ^ a3;
 x20 = a4 & x15;
 out1 ^=
     (a6 & ((a1 & ((a4 & (x5 ^ x6)) ^ (a5 & x9) ^ x9)) ^ (a4 & (x13 ^ x9)) ^ x15)) ^
     (a1 & x15) ^ x20 ^ a5 ^ x6;

 x27 = a2 & a3;
 x30 = x1 & a3;
 x29 = a5 & x30;
 x34 = a5 & a2;
 x33 = a4 & x34;
 x41 = x1 ^ a3;
 x40 = a5 & x41;
 x46 = a5 & a3;
 out2 ^=
     (a6 & ((a1 & ((a4 & (a5 ^ x27)) ^ x29 ^ x30)) ^ (~x33))) ^
     (a1 & ((a4 & x40) ^ (a5 & x27) ^ x9)) ^ (a4 & (x46 ^ x1)) ^ x13 ^ x41;

 x57 = ~x34;
 x62 = a2 | a3;
 out3 ^=
     (a6 & ((a1 & ((a4 & x5) ^ x29 ^ x2)) ^ (a4 & a5) ^ x57)) ^
     (a1 & (x33 ^ x13 ^ x62)) ^ (a4 & x57) ^ x29 ^ x27;

 out4 ^=
     (a6 & ((a1 & ((a4 & (x40 ^ a2 ^ a3)) ^ x6)) ^ (a4 & (x40 ^ x30)))) ^
     (a1 & (x20 ^ (~x46))) ^ (a4 & (x46 ^ x62)) ^ a5 ^ x30;
}


void
s7 (
 unsigned long	a1,
 unsigned long	a2,
 unsigned long	a3,
 unsigned long	a4,
 unsigned long	a5,
 unsigned long	a6,
 unsigned long	&out1,
 unsigned long	&out2,
 unsigned long	&out3,
 unsigned long	&out4
) {
        unsigned long	 x1,x2,x6,x5,x7,x17,x19,x24,x23,x25,x31,x33,x41,x48,x59;

 x1 = ~a1;
 x2 = ~a6;
 x6 = x2 & x1;
 x5 = a3 & x6;
 x7 = a1 & a6;
 x17 = a3 & a1;
 x19 = x17 ^ (x1 | a6);
 x24 = x2 | x1;
 x23 = a3 & x24;
 x25 = x1 & a6;
 out1 ^=
     (a4 & ((a5 & ((a2 & a1) ^ x5 ^ x7)) ^ (a2 & (x5 ^ x1)) ^ a1)) ^
     (a5 & ((a2 & x17) ^ x19)) ^ (a2 & (x5 ^ a1)) ^ x23 ^ x25;

 x31 = a2 & x25;
 x33 = a1 ^ a6;
 x41 = x1 ^ a6;
 out2 ^=
     (a4 & ((a5 & (x31 ^ (a3 & x33))) ^ (a2 & (x17 ^ x24)) ^ x1)) ^
     a5 ^ (a2 & (x23 ^ x41)) ^ x19;

 x48 = a3 & x25;
 x59 = a3 & (x2 & a1);
 out3 ^=
     (a4 & ((a5 & ((a2 & x41) ^ x48 ^ x2)) ^ (a2 & (x48 ^ a1)) ^ (~x48))) ^
     (a5 & ((a2 & x59) ^ (x59 ^ x6))) ^ (a2 & (~x59)) ^ (a3 & x41) ^ x7;


 out4 ^=
     (a4 & ((a5 & ((a2 & a6) ^ (x23 ^ x24))) ^ x31 ^ x23 ^ x7)) ^
     (a5 & (~(a2 & x7))) ^ (a2 & (~x23)) ^ a3 ^ x33;
}


void
s8 (
 unsigned long	a1,
 unsigned long	a2,
 unsigned long	a3,
 unsigned long	a4,
 unsigned long	a5,
 unsigned long	a6,
 unsigned long	&out1,
 unsigned long	&out2,
 unsigned long	&out3,
 unsigned long	&out4
) {
 unsigned long	 x1,x2,x6,x5,x7,x4,x10,x9,x14,x13,x16,x22,x33,x34,x43,x44,x45,x52,x65;

 x1 = ~a3;
 x2 = ~a5;
 x6 = x1 ^ a5;
 x5 = a4 & x6;
 x7 = x2 & a3;
 x4 = a2 & (x5 ^ x7);
 x10 = a3 ^ a5;
 x9 = a4 & x10;
 x14 = a4 & a3;
 x13 = a2 & x14;
 x16 = x9 ^ (x2 | x1);
 x22 = a4 & x1;
 out1 ^=
     (a1 & ((a6 & (x4 ^ x9 ^ x6)) ^ x13 ^ x16)) ^
     (a6 & ((a2 & (x22 ^ x2)) ^ (~x5))) ^ (a2 & (x5 ^ a5)) ^ x14 ^ x6;

 x33 = x1 & a5;
 x34 = x22 ^ x33;
 x43 = a4 & x2;
 x44 = x43 ^ x6;
 x45 = x2 | a3;
 out2 ^=
     (a1 & ((a6 & (x13 ^ x34)) ^ (a2 & (x5 ^ x10)) ^ x22 ^ x7)) ^
     a6 ^ (a2 & x44) ^ a4 ^ x45;

 x52 = a4 & a5;
 x65 = a3 | a5;
 out3 ^=
     (a1 & ((a6 & ((a2 & (x52 ^ (a3 & a5))) ^ x43 ^ a5)) ^ (a2 & x33) ^ x43 ^ x45)) ^
     (a6 & (a2 & (x5 ^ x6))) ^ a2 ^ x52 ^ x65;

 out4 ^=
     (a1 & ((a6 & ((a2 & x34) ^ x16)) ^ ((a2 & (x43 ^ x7)) ^ x65))) ^
     (a6 & ((a2 & x10) ^ (a4 & (x1 | a5)) ^ x33)) ^ (a2 & (~x52)) ^ x44;
}



