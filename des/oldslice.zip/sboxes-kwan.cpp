#include "sboxes.h"

#ifndef KWAN
#error "You must compile with -DKWAN.  Set this and then recompile cliconfig.cpp"
#endif

/*
 * Generated S-box files.
 *
 * Produced by Matthew Kwan - April 1997
 */

void
s1 (
	unsigned long	a1,
	unsigned long	a2,
	unsigned long	a3,
	unsigned long	a4,
	unsigned long	a5,
	unsigned long	a6,
	unsigned long	&out1,
	unsigned long	&out2,
	unsigned long	&out3,
	unsigned long	&out4
) {
	unsigned long  x1,x2,x5,x8,x11,x13,x20,x19,x30,x29,x35,x36,x37,x45,x57,x55,x60,x61;
	
	x1 = ~a2;
	x2 = ~a6;
	x5 = x2 & x1;
	x8 = a5 ^ x1 ^ a6;
	x11 = a5 & a2;
	x13 = a5 & a6;
	x20 = x2 | x1;
	x19 = a5 & x20;
	out1 ^=
	    (a4 & ((a3 & ((a1 & (a5 ^ x5)) ^ x8)) ^ (a1 & (x11 ^ x5)) ^ x13)) ^
	    (a3 & ((a1 & (x19 ^ a2)) ^ x1)) ^ (a1 & (~x19)) ^ x8;
	
	x30 = x1 | a6;
	x29 = a1 & (x13 ^ x30);
	x35 = a5 & x1;
	x36 = a2 | a6;
	x37 = x35 ^ x36;
	x45 = a5 & x2;
	out2 ^=
	    (a4 & ((a3 & (x29 ^ x13 ^ a6)) ^ (a1 & x19) ^ x37)) ^
	    (a3 & ((a1 & ((a5 & x36) ^ x30)) ^ (x45 ^ x20))) ^ (a1 & x37) ^ x13 ^ x5;
	
	x57 = x2 & a2;
	x55 = a1 & ((a5 & x57) ^ x57);
	x60 = x2 | a2;
	x61 = (a5 & x60) ^ x30;
	out3 ^=
	    (a4 & ((a3 & (x29 ^ x5)) ^ x55 ^ x61)) ^ (a3 & (x55 ^ x37)) ^ (a1 & x61) ^ x35 ^ x60;
	
	out4 ^=
	    (a4 & ((a3 & a1 & (x45 ^ x5)) ^ (a1 & (x35 ^ x2)) ^ x11 ^ x20)) ^
	    (a3 & ((a1 & (x19 ^ x1)) ^ x19 ^ (a2 & a6))) ^
	    (a1 & ((a5 & x5) ^ a6)) ^ (a5 & (a2 ^ a6)) ^ x57;
}


void
s2 (
	unsigned long	a1,
	unsigned long	a2,
	unsigned long	a3,
	unsigned long	a4,
	unsigned long	a5,
	unsigned long	a6,
	unsigned long	&out1,
	unsigned long	&out2,
	unsigned long	&out3,
	unsigned long	&out4
) {
	unsigned long	x1,x2,x5,x4,x13,x14,x19,x21,x23,x24,x30,x38,x47,x55;

	x1 = ~a5;
	x2 = ~a6;
	x5 = x2 & a5;
	x4 = a2 & x5;
	x13 = a2 & x2;
	x14 = a5 & a6;
	x19 = a2 & x1 & a6;
	x21 = x2 | x1;
	x23 = a2 & a6;
	x24 = x1 ^ a6;
	out1 ^=
	    (a4 & ((a1 & (x4 ^ x5)) ^ (a2 & x1) ^ a5)) ^
	    (a3 & ((a1 & (x13 ^ x14)) ^ (~x13))) ^ (a1 & (x19 ^ x21)) ^ x23 ^ x24;
	
	x30 = a1 & x4;
	x38 = a2 ^ x24;
	out2 ^=
	    (a4 & ((a3 & x14) ^ x30 ^ x13 ^ x21)) ^ (a3 & (x30 ^ (a2 ^ a6))) ^ a1 ^ x38;
	
	x47 = x2 | a5;
	x55 = a2 & (x1 | a6);
	out3 ^=
	    (a4 & ((a3 & ((a1 & x38) ^ x24)) ^ (a1 & ((a2 & x47) ^ a5)) ^ (~x19))) ^
	    (a3 & ((a1 & (x55 ^ x1)) ^ x23 ^ a5)) ^ (a1 & ((a2 & x24) ^ x21)) ^ (a2 & x21) ^ x1;
	
	out4 ^=
	    (a4 & ((a1 & (x23 ^ x14)) ^ x4 ^ x21)) ^
	    (a3 & ((a1 & (x19 ^ (x2 & x1))) ^ x4 ^ x24)) ^ (a1 & (x55 ^ x47)) ^ ~x23;
}


void
s3 (
	unsigned long	a1,
	unsigned long	a2,
	unsigned long	a3,
	unsigned long	a4,
	unsigned long	a5,
	unsigned long	a6,
	unsigned long	&out1,
	unsigned long	&out2,
	unsigned long	&out3,
	unsigned long	&out4
) {
	unsigned long
	    x1,x2,x5,x6,x9,x11,x19,x21,x23,x24,x31,x33,x35,x42,x43,x41,x48,x57,x74,x83;

	x1 = ~a1;
	x2 = ~a2;
	x5 = a6 & x1;
	x6 = x2 & x1;
	x9 = a6 & x6;
	x11 = a1 | a2;
	x19 = a1 ^ a2;
	x21 = x1 | a2;
	x23 = a6 & a1;
	x24 = x2 | a1;
	out1 ^=
	    (a4 & ((a3 & ((a5 & x5) ^ x6)) ^ (a5 & (x9 ^ x6)) ^ x5 ^ x11)) ^
	    (a3 & ((a5 & ((a6 & x19) ^ x2)) ^ x21)) ^ a5 ^ x23 ^ x24;
	
	x31 = x1 & a2;
	x33 = a5 & (~x5);
	x35 = a6 & x2;
	x42 = a6 & x31;
	x43 = x42 ^ x24;
	x41 = a5 & x43;
	x48 = x2 & a1;
	out2 ^=
	    (a4 & ((a3 & ((a5 & x23) ^ x31)) ^ (x33 ^ x35 ^ x31))) ^
	    (a3 & (x41 ^ x43)) ^ (a5 & (x42 ^ x31)) ^ (a6 & x24) ^ x48;
	
	x57 = a6 & x21;
	out3 ^=
	    (a4 & ((a3 & (x33 ^ x9 ^ x24)) ^ (a5 & (x57 ^ x19)) ^ x57 ^ x6)) ^
	    (a3 & ((a5 & (x5 ^ x1)) ^ x35 ^ a2)) ^ x41 ^ x57 ^ x1 ^ a2;
	
	x74 = a6 & a1 & a2;
	x83 = x74 ^ x48;
	out4 ^=
	    (a4 & ((a3 & x74) ^ (a5 & x1) ^ (~x23))) ^
	    (a3 & ((a5 & x21) ^ x83)) ^ (a5 & x83) ^ x57 ^ x11;
}


void
s4 (
	unsigned long	a1,
	unsigned long	a2,
	unsigned long	a3,
	unsigned long	a4,
	unsigned long	a5,
	unsigned long	a6,
	unsigned long	&out1,
	unsigned long	&out2,
	unsigned long	&out3,
	unsigned long	&out4
) {
	unsigned long
	    x1,x2,x5,x4,x7,x6,x3,x12,x11,x13,x10,x15,x16,x22,x23,x21,x20,x38,x42,x47,x48,x51;

	x1 = ~a3;
	x2 = ~a5;
	x5 = a3 ^ a5;
	x4 = a2 & x5;
	x7 = x1 | a5;
	x6 = a1 & x7;
	x3 = a4 & (x4 ^ x6 ^ x2);
	x12 = x1 & a5;
	x11 = a1 & x12;
	x13 = x2 | a3;
	x10 = a2 & (x11 ^ x13);
	x15 = x1 ^ a5;
	x16 = x11 ^ x15;
	x22 = a1 & x15;
	x23 = x22 ^ a5;
	x21 = a2 & x23;
	x20 = x3 ^ x10;
	out1 ^=
	    (a6 & (x20 ^ x16)) ^ (a4 & (x21 ^ (~x6))) ^ (a2 & (x11 ^ (a3 | a5))) ^ a1 ^ x12;

	x38 = a2 & (x22 ^ a3);
	x42 = a1 & x13;
	out2 ^=
	    (a6 & (x3 ^ x10 ^ x11 ^ x5)) ^ (a4 & (x38 ^ a5)) ^ (a2 & x1) ^ x42 ^ x7;

	x47 = a4 & (x4 ^ x42 ^ (x2 | x1));
	x51 = a2 & ((a1 & x2 & a3) ^ x15);
	x48 = x47 ^ x51;
	out3 ^=
	    (a6 & (x48 ^ x22 ^ x2)) ^ (a4 & (x38 ^ x42 ^ x12)) ^ (a2 & (~x42)) ^ x16;
	
	out4 ^=
	    (a6 & (x48 ^ x23)) ^ (a4 & (x21 ^ x2)) ^ (a2 & (x22 ^ x5)) ^ x6 ^ x1;
}


void
s5 (
	unsigned long	a1,
	unsigned long	a2,
	unsigned long	a3,
	unsigned long	a4,
	unsigned long	a5,
	unsigned long	a6,
	unsigned long	&out1,
	unsigned long	&out2,
	unsigned long	&out3,
	unsigned long	&out4
) {
	unsigned long	x1,x2,x5,x6,x7,x14,x23,x22,x25,x29,x30,x33,x32,x41,x48,x51,x58,x59,x61;
	
	x1 = ~a3;
	x2 = ~a6;
	x5 = a4 & x2;
	x6 = x5 ^ a6;
	x7 = a3 & a6;
	x14 = a4 & (x1 | a6);
	x23 = x1 ^ a6;
	x22 = a4 & x23;
	x25 = x2 | x1;
	x29 = a4 & a6;
	x30 = x2 & a3;
	x33 = a3 | a6;
	x32 = a4 & x33;
	out1 ^=
	    (a5 & ((a2 & ((a1 & x6) ^ a4 ^ x7)) ^ (a1 & ((a4 & a3) ^ (x2 | a3))) ^ x14 ^ x2)) ^
	    (a2 & ((a1 & (x22 ^ x7)) ^ x5 ^ x25)) ^ (a1 & (x29 ^ x30)) ^ x32 ^ (x1 & a6);
	
	x41 = a4 & x7;
	x48 = a4 & x25;
	x51 = x48 ^ x33;
	out2 ^=
	    (a5 & ((a1 & (x22 ^ a6)) ^ x41 ^ x25)) ^
	    (a2 & ((a1 & (x32 ^ x33)) ^ x48 ^ x7)) ^ a1 ^ x51;
	
	x58 = x2 & x1;
	x59 = a4 ^ x58;
	x61 = a1 & (x14 ^ a3 ^ a6);
	out3 ^=
	    (a5 & ((a2 & ((a1 & (x29 ^ x25)) ^ x59)) ^ x61 ^ x14 ^ x23)) ^
	    (a2 & (x61 ^ (~x32))) ^ (a1 & (x14 ^ x58)) ^ (a4 & x58) ^ x25;
	
	out4 ^=
	    (a5 & ((a2 & ((a1 & x59) ^ x29 ^ x23)) ^ (a1 & x14) ^ x14 ^ x33)) ^
	    (a2 & ((a1 & ((a4 & x1) ^ x58)) ^ x6)) ^ (a1 & x51) ^ x41 ^ x30;
}


void
s6 (
	unsigned long	a1,
	unsigned long	a2,
	unsigned long	a3,
	unsigned long	a4,
	unsigned long	a5,
	unsigned long	a6,
	unsigned long	&out1,
	unsigned long	&out2,
	unsigned long	&out3,
	unsigned long	&out4
) {
	unsigned long	x1,x2,x5,x6,x9,x13,x15,x20,x27,x29,x30,x34,x33,x41,x40,x46,x57,x62;

	x1 = ~a2;
	x2 = ~a3;
	x5 = a5 & x1;
	x6 = x1 | a3;
	x9 = x2 | a2;
	x13 = a5 & x2;
	x15 = x13 ^ a3;
	x20 = a4 & x15;
	out1 ^=
	    (a6 & ((a1 & ((a4 & (x5 ^ x6)) ^ (a5 & x9) ^ x9)) ^ (a4 & (x13 ^ x9)) ^ x15)) ^
	    (a1 & x15) ^ x20 ^ a5 ^ x6;
	
	x27 = a2 & a3;
	x30 = x1 & a3;
	x29 = a5 & x30;
	x34 = a5 & a2;
	x33 = a4 & x34;
	x41 = x1 ^ a3;
	x40 = a5 & x41;
	x46 = a5 & a3;
	out2 ^=
	    (a6 & ((a1 & ((a4 & (a5 ^ x27)) ^ x29 ^ x30)) ^ (~x33))) ^
	    (a1 & ((a4 & x40) ^ (a5 & x27) ^ x9)) ^ (a4 & (x46 ^ x1)) ^ x13 ^ x41;
	
	x57 = ~x34;
	x62 = a2 | a3;
	out3 ^=
	    (a6 & ((a1 & ((a4 & x5) ^ x29 ^ x2)) ^ (a4 & a5) ^ x57)) ^
	    (a1 & (x33 ^ x13 ^ x62)) ^ (a4 & x57) ^ x29 ^ x27;
	
	out4 ^=
	    (a6 & ((a1 & ((a4 & (x40 ^ a2 ^ a3)) ^ x6)) ^ (a4 & (x40 ^ x30)))) ^
	    (a1 & (x20 ^ (~x46))) ^ (a4 & (x46 ^ x62)) ^ a5 ^ x30;
}


void
s7 (
	unsigned long	a1,
	unsigned long	a2,
	unsigned long	a3,
	unsigned long	a4,
	unsigned long	a5,
	unsigned long	a6,
	unsigned long	&out1,
	unsigned long	&out2,
	unsigned long	&out3,
	unsigned long	&out4
) {
        unsigned long	 x1,x2,x6,x5,x7,x17,x19,x24,x23,x25,x31,x33,x41,x48,x59;

	x1 = ~a1;
	x2 = ~a6;
	x6 = x2 & x1;
	x5 = a3 & x6;
	x7 = a1 & a6;
	x17 = a3 & a1;
	x19 = x17 ^ (x1 | a6);
	x24 = x2 | x1;
	x23 = a3 & x24;
	x25 = x1 & a6;
	out1 ^=
	    (a4 & ((a5 & ((a2 & a1) ^ x5 ^ x7)) ^ (a2 & (x5 ^ x1)) ^ a1)) ^
	    (a5 & ((a2 & x17) ^ x19)) ^ (a2 & (x5 ^ a1)) ^ x23 ^ x25;

	x31 = a2 & x25;
	x33 = a1 ^ a6;
	x41 = x1 ^ a6;
	out2 ^=
	    (a4 & ((a5 & (x31 ^ (a3 & x33))) ^ (a2 & (x17 ^ x24)) ^ x1)) ^
	    a5 ^ (a2 & (x23 ^ x41)) ^ x19;

	x48 = a3 & x25;
	x59 = a3 & (x2 & a1);
	out3 ^=
	    (a4 & ((a5 & ((a2 & x41) ^ x48 ^ x2)) ^ (a2 & (x48 ^ a1)) ^ (~x48))) ^
	    (a5 & ((a2 & x59) ^ (x59 ^ x6))) ^ (a2 & (~x59)) ^ (a3 & x41) ^ x7;

	
	out4 ^=
	    (a4 & ((a5 & ((a2 & a6) ^ (x23 ^ x24))) ^ x31 ^ x23 ^ x7)) ^
	    (a5 & (~(a2 & x7))) ^ (a2 & (~x23)) ^ a3 ^ x33;
}


void
s8 (
	unsigned long	a1,
	unsigned long	a2,
	unsigned long	a3,
	unsigned long	a4,
	unsigned long	a5,
	unsigned long	a6,
	unsigned long	&out1,
	unsigned long	&out2,
	unsigned long	&out3,
	unsigned long	&out4
) {
	unsigned long	 x1,x2,x6,x5,x7,x4,x10,x9,x14,x13,x16,x22,x33,x34,x43,x44,x45,x52,x65;

	x1 = ~a3;
	x2 = ~a5;
	x6 = x1 ^ a5;
	x5 = a4 & x6;
	x7 = x2 & a3;
	x4 = a2 & (x5 ^ x7);
	x10 = a3 ^ a5;
	x9 = a4 & x10;
	x14 = a4 & a3;
	x13 = a2 & x14;
	x16 = x9 ^ (x2 | x1);
	x22 = a4 & x1;
	out1 ^=
	    (a1 & ((a6 & (x4 ^ x9 ^ x6)) ^ x13 ^ x16)) ^
	    (a6 & ((a2 & (x22 ^ x2)) ^ (~x5))) ^ (a2 & (x5 ^ a5)) ^ x14 ^ x6;
	
	x33 = x1 & a5;
	x34 = x22 ^ x33;
	x43 = a4 & x2;
	x44 = x43 ^ x6;
	x45 = x2 | a3;
	out2 ^=
	    (a1 & ((a6 & (x13 ^ x34)) ^ (a2 & (x5 ^ x10)) ^ x22 ^ x7)) ^
	    a6 ^ (a2 & x44) ^ a4 ^ x45;

	x52 = a4 & a5;
	x65 = a3 | a5;
	out3 ^=
	    (a1 & ((a6 & ((a2 & (x52 ^ (a3 & a5))) ^ x43 ^ a5)) ^ (a2 & x33) ^ x43 ^ x45)) ^
	    (a6 & (a2 & (x5 ^ x6))) ^ a2 ^ x52 ^ x65;

	out4 ^=
	    (a1 & ((a6 & ((a2 & x34) ^ x16)) ^ ((a2 & (x43 ^ x7)) ^ x65))) ^
	    (a6 & ((a2 & x10) ^ (a4 & (x1 | a5)) ^ x33)) ^ (a2 & (~x52)) ^ x44;
}


