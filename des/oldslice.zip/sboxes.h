#ifndef _SBOXES_H
#define _SBOXES_H

extern void
s1 (	unsigned long	a1,
	unsigned long	a2,
	unsigned long	a3,
	unsigned long	a4,
	unsigned long	a5,
	unsigned long	a6,
	unsigned long	&out1,
	unsigned long	&out2,
	unsigned long	&out3,
	unsigned long	&out4);
extern void
s2 (	unsigned long	a1,
	unsigned long	a2,
	unsigned long	a3,
	unsigned long	a4,
	unsigned long	a5,
	unsigned long	a6,
	unsigned long	&out1,
	unsigned long	&out2,
	unsigned long	&out3,
	unsigned long	&out4);
extern void
s3 (	unsigned long	a1,
	unsigned long	a2,
	unsigned long	a3,
	unsigned long	a4,
	unsigned long	a5,
	unsigned long	a6,
	unsigned long	&out1,
	unsigned long	&out2,
	unsigned long	&out3,
	unsigned long	&out4);
extern void
s4 (	unsigned long	a1,
	unsigned long	a2,
	unsigned long	a3,
	unsigned long	a4,
	unsigned long	a5,
	unsigned long	a6,
	unsigned long	&out1,
	unsigned long	&out2,
	unsigned long	&out3,
	unsigned long	&out4);
extern void
s5 (	unsigned long	a1,
	unsigned long	a2,
	unsigned long	a3,
	unsigned long	a4,
	unsigned long	a5,
	unsigned long	a6,
	unsigned long	&out1,
	unsigned long	&out2,
	unsigned long	&out3,
	unsigned long	&out4);
extern void
s6 (	unsigned long	a1,
	unsigned long	a2,
	unsigned long	a3,
	unsigned long	a4,
	unsigned long	a5,
	unsigned long	a6,
	unsigned long	&out1,
	unsigned long	&out2,
	unsigned long	&out3,
	unsigned long	&out4);
extern void
s7 (	unsigned long	a1,
	unsigned long	a2,
	unsigned long	a3,
	unsigned long	a4,
	unsigned long	a5,
	unsigned long	a6,
	unsigned long	&out1,
	unsigned long	&out2,
	unsigned long	&out3,
	unsigned long	&out4);
extern void
s8 (	unsigned long	a1,
	unsigned long	a2,
	unsigned long	a3,
	unsigned long	a4,
	unsigned long	a5,
	unsigned long	a6,
	unsigned long	&out1,
	unsigned long	&out2,
	unsigned long	&out3,
	unsigned long	&out4);

#endif
