/* Icons and Menus */
#define ID_RESOURCE                 1
#define ID_COW                      7
#define ID_MONARCH                  2
#define ID_OSCAR                    3
#define ID_OK                       4
#define ID_BOOK                     5
#define ID_NOTEBOOK                 6
#define ID_CLIENT_ICON              8

/* Bitmaps */     
#define IMG_TEXTURE                 10

/* Dialog Window */
#define DID_WND                     50
#define DID_ABOUT                   51
#define DID_CONFIG                  52
#define DID_NOTEBOOK                53

/* Button IDs */
#define ID_OUTPUT                   101
#define ID_FETCH                    102
#define ID_FLUSH                    103
#define ID_UPDATE                   104
#define ID_BUFF_IN                  105
#define ID_PERCENT                  106
#define ID_BUFF_OUT                 107
#define ID_STATUS                   108
#define IDM_SHOWPERCENT             109

/* Menu IDs */
/* Options */
#define IDM_CLIENT                  200
#define IDM_START                   201
#define IDM_STOP                    202
#define IDM_OPTIONS                 203
#define IDM_CONFIG                  204
#define IDM_TEST                    205
#define IDM_BENCH                   206
#define IDM_BENCH2                  207

/* Block */
#define IDM_BLOCK                   210
#define IDM_FLUSH                   211
#define IDM_FETCH                   212
#define IDM_UPDATE                  213

/* About */
#define IDM_HELP                    214
#define IDM_ABOUT                   215

#define ID_EMAIL                    301
#define ID_BUFFER                   303
#define ID_COMPLETE                 304
#define ID_BLOCK_COMPLETE           305
#define ID_HOURS_COMPLETE           306
#define ID_SAVE                     307
#define ID_LOGNAME                  308
#define ID_CANCEL                   309
#define ID_NETWORKMODE              310
#define ID_CPU                      312
#define ID_PRIORITY                 313
#define ID_NETWORK                  314
#define ID_KEYPORT                  315
#define ID_HTTP_PROXY               316
#define ID_PROXY                    317
#define ID_UUENCODING               318
#define ID_HTTPHEADER               319
#define ID_HTTPPORT                 321
#define ID_STARTUP                  322
#define ID_MINIMIZE                 323
#define ID_SHOWPERCENT              324
#define ID_PERCENT_BAR              325

#define DID_EMAIL                   300
#define DID_NETWORK                 100
#define DID_BLOCK_CONFIG            500
#define ID_BLOCKIN                  501
#define ID_BLOCKOUT                 502
#define DID_SYSTEM                  550
#define DID_MAIL_CONFIG             600
#define ID_NUM_CPU                  560
#define ID_MAIL_MESG                601
#define ID_SMTP_SERVER              602
#define ID_SMTP_PORT                603
#define ID_SMTP_FROM                604
#define ID_SMTP_TO                  605
#define ID_HTTP_PASS_TXT            111
#define DID_QUERY_HTTP_PASS         400
#define ID_PROXY_USER               402
#define ID_PROXY_PASS               403
#define IDM_HTTP_PASS               112
#define DID_OS2_OPTIONS             700
#define DID_OPTIONS                 900
#define ID_RUNOFFLINE               901
#define ID_RUNBUFFERS               902
#define ID_CHECKPOINT               903
#define ID_CHECKPOINT_FILE          904
#define ID_CHECKPOINT_INT           905
#define ID_CHECKPOINT_INT_VALUE     906
#define ID_NETWORKTIMEOUT           907
#define ID_NETWORKTIMEOUT_VAL       908
#define ID_FREQUENT                 912
#define ID_EXITFILECHECK            909
#define ID_NOFALLBACK               914
#define ID_NODISKBUFFERS            910
#define ID_ABOUT_VERSION            911

#define ID_BLOCKIN_DES              503
#define ID_BLOCKOUT_DES             504
#define ID_SOCKS4                   113
#define ID_CHECKPOINT_FILE_DES      913
#define ID_BLOCK_SIZE               915
#define ID_CONTEST                  916
